AngularJS Chat Room
=====================
一个基于AngularJS、NodeJS、Express、socket.io搭建的在线聊天室。

##DEMO
地址：http://45.79.97.45:3002/

##How to use

  git clone https://github.com/sheila1227/ChatRoom-AngularJS
  
  cd ChatRoom-AngularJS
  
  ...
  
  npm install
  
  ...
  
  node app.js
